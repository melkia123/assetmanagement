<?php
include('../users/db.php');

if(isset($_POST['viiew_id'])) {
    $id = $_POST['viiew_id'];
    $query = "SELECT * FROM assetusers WHERE id = '$id'";
    $query_run = mysqli_query($con, $query);

    if(mysqli_num_rows($query_run) > 0) {
        foreach($query_run as $row) {
            $response = array(
                "id" => $row['id'],
                "fname" => $row['fname'],
                "lname" => $row['lname'],
                "email" => $row['email'],
                "username" => $row['username'],
                "password" => $row['password']
            );
            echo json_encode($response);
        }
    } else {
        echo "No record found";
    }
}
?>