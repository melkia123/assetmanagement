<?php
$host="localhost";
$user="root";
$pass="";
$db="asset";
$con=mysqli_connect($host,$user,$pass,$db);
if(isset($con)){
}else
{
echo"can not connected";
}
?>