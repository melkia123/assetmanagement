<!DOCTYPE html>
<html>
<head>
    <title>Asset Transfer Page</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/assign_asset.css">
    <style>
        body{
            background-image: url(photo8.jpg);
    background-reapt:non-reapt;
    background-size:cover;
        }
    .logo {
    background-color: #333;
    padding: 10px;
    margin:none;
}

.logo h1 {
    
    margin: 0;
    color: white;
}

.menu {
    background-color: #333;
}

.menu ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
}

.menu ul li {
    margin-top:5px;
    height:20px;
    float: left;
    margin-left:250px;
    border:1px solid greenyellow;
}

.menu ul li a {
    display: block;
    color: white;
    text-align: center;
    padding: 3px 5px;
    text-decoration: none;
}

.menu ul li a:hover {
    background-color: #111;
}

.main {
    margin: 20px;
    height:60vh;
    display:flex;
    justify-content:center;
    align-items:center;
    

}

.box{
    
    border:15px solid black;
    height:40vh;
    width:55vh;
}
.container {
    display: flex;
    flex-direction: column;
    margin-bottom: 20px;
}

.container p {
    margin: 0;
    color:white;
    text-align:center;
}

.container input[type="text"] {
    background-color: greenyellow;
    color:black;
    width: 300px;
    padding: 10px;
    padding-bottom:20px;
    height:20px;
    border-radius:10px;
    margin-left:10px;
}

.assign input[type="submit"] {
    padding: 10px 20px;
    background-color: #333;
    color: white;
    border: none;
    margin-left:50px;
}

.footer {
    height:80px;
    background-color: #333;
    padding: 10px;
    color: white;
    text-align: center;
}
.success-message{
    color:white;
    font-size:30px;
    font-weight:bold;
text-align:center;
margin-top:5px;
}
    </style>
</head>
<body>
    <div class="logo">
        <marquee direction="left/right"><h1><a href="http://localhost/assetmanagement" style="color:white">WELCOME TO ASSIGN ASSET PAGE</a></h1></marquee>
    </div>
    <div class="menu">
        <ul>
            <li><a href="http://localhost/assetmanagement/asset/index.php">Asset</a></li>
            <li><a href="http://localhost/assetmanagement/include/admin/manager.php">Mnager</a></li>
            <li><a href="http://localhost/assetmanagement/include/users/logout.php">Logout</a></li>
        </ul>
    </div>
    <div class="main">
        <form action="asset-transfer.php" method="post">
            <div class="box">
            <div class="container">
                <p>Asset ID</p><br>
                <input type="text" name="assetid">
                <p>New User ID</p><br>
                <input type="text" name="newuserid">
            </div>
            <div class="assign">
                <input type="submit" name="transfer" value="Transfer Asset">
            </div>
            </div>
        </form>
    </div>

    <?php
        // PHP code here
        include('db.php');
        if(isset($con)) {
            if(isset($_POST['transfer'])){
                $assetid=$_POST['assetid'];
                $newuserid=$_POST['newuserid'];

                // Fetch the current user's name
                $getUserSql = "SELECT fname FROM assetusers WHERE id = '$assetid'";
                $getUserExc = mysqli_query($con, $getUserSql);
                if($getUserExc && mysqli_num_rows($getUserExc) > 0) {
                    $currentUser = mysqli_fetch_assoc($getUserExc)['fname'];
                } else {
                    $currentUser = "Unknown User";
                }

                // Fetch the new user's name
                $getNewUserSql = "SELECT fname FROM assetusers WHERE id = '$newuserid'";
                $getNewUserExc = mysqli_query($con, $getNewUserSql);
                if($getNewUserExc && mysqli_num_rows($getNewUserExc) > 0) {
                    $newUser = mysqli_fetch_assoc($getNewUserExc)['fname'];
                } else {
                    $newUser = "Unknown User";
                }

                // SQL code to update the asset with the new user ID
                $updateSql = "UPDATE asset SET assigned_to = '$newuserid' WHERE id = '$assetid'";
                $updateExc = mysqli_query($con, $updateSql);

                if(isset($updateExc)){
                    echo "<p class='success-message'>Asset Transferred from $currentUser to $newUser Successfully</p>";
                } else {
                    echo "Something went wrong while transferring the asset";
                }
            }
        }
    ?>
    </div>
    <div class="footer">Here is the footer</div>

</body>
</html>