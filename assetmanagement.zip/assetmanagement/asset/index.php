<!DOCTYPE html>
<html>
    <head>
        <title>asset-management</title>
        <link rel="stylesheet" type="text/css" href="../css/style.css">
        <?php
    session_start();
        ?>
        <style>
            .main{
                width: 100%;
                height: 600px;
            }
    .grid-container {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 10px;
}

.asset {
    padding: 10px;
    border-radius: 5px;
}

.asset img {
    max-width: 100%;
    height: auto;
}


    
.mennu{
    border: 1px solid green;
    list-style: none;
    background-color:#035356;
    color:rgb(22, 113, 193);
    text-decoration: none;
    height:100px;
    width: calc(100%);
}
.foter{
    border: 1px solid red;
    background: blueviolet;
     color: white;
        height: 43px;
        width: calc(100%);
    }
    .mennu li{
        text-align: center;
        width: 80px;
        height: 20px;
        margin-top: 20px;
        margin-left: 4%;
        text-decoration: white;
        display:inline-flex;
        border: 1px solid greenyellow;
        background-color: black;
    }
    .mennu a{
        text-align: center;
        text-decoration: none;
        color: white;
    }
        </style>
    </head>
    <body>
    <div class="mennu">
        <ul>
            <?php
           if(isset($_SESSION['id'])){
            ?>
            
            <?php
           }else{
            ?>
            <li><a href="http://localhost/assetmanagement/index.php">Home</a></li>
            <?php
           }
           ?>
            <li><a href="http://localhost/assetmanagement/asset/index.php">Asset</a></li>
            <li><a href="http://localhost/assetmanagement/include/admin/dashboard.php">Admin</a></li>
            <li><a href="http://localhost/assetmanagement/include/users/login.php">Login</a></li>
            <li><a href="http://localhost/assetmanagement/include/users/signup.php">Signup</a></li>
            <li><a href="http://localhost/assetmanagement/include/users/logout.php">Logout</a></li>
            <?php
            if(isset($_SESSION['id'])){
            ?>
           
            <?php
             }else{
                ?>
                
            <?php
        }
        ?>
        </ul>
    </div>
    <div class="main">
    <?php
include('../include/users/db.php');
$sql = "SELECT * FROM asset";
$res = mysqli_query($con, $sql);

// Initialize variables for each grid
$grid1 = '';
$grid2 = '';

if (isset($res)) {
    while ($result = mysqli_fetch_array($res)) {
        $assetname = $result['assetname'];
        $image = $result['image'];

        // Check if assetname and image are not empty before adding to grid
        if (!empty($assetname) && !empty($image)) {
            // Determine which grid to add the image to
            if (empty($grid1) || count(explode('<div class="asset">', $grid1)) <= count(explode('<div class="asset">', $grid2))) {
                $grid1 .= '<div class="asset"><h3>' . $assetname . '</h3><img src="image/' . $image . '" alt="' . $assetname . '"></div>';
            } else {
                $grid2 .= '<div class="asset"><h3>' . $assetname . '</h3><img src="image/' . $image . '" alt="' . $assetname . '"></div>';
            }
        }
    }
}

// Display the two grids
echo '<div class="grid-container">' . $grid1 . '</div>';
echo '<div class="grid-container">' . $grid2 . '</div>';
?>

        </div>
    <div class="foter"> <h1>here is footer</h1></div>
    </div>
    </body>

</html>