<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<style>
    body{
        background-image: url(dashboared.jpg);
    background-reapt:non-reapt;
    background-size:cover;
    }
    .cont input{
    width: 40%;
    margin-bottom: 3px;
    color: black;
}
.cont input[type="text"],input[type="email"],input[type="password"]{
    border: none;
    border-bottom: 1px solid #fff;
    background-color: white;
    outline: none;
    height: 30px;
    border-radius: 20px;80px;
    width:
}

.cont input[type="submit"]{
    border: none;
    outline: none;
    height: 15px;
    background-color: aquamarine;
    color: black;
    border-radius: 20px;
}
.cont input[type="submit"]:hover{
    cursor: pointer;
    background-color: #ffc107;
}

.maiin{
    height:400px;
    width:70%;
    border:20px solid greenyellow;
    margin-left:200px;
    margin-top:50px;
    margin-bottom:50px;

}
h2,p{
    color:white;
}
table{
    border:2px solid greenyellow;
    height:100%;
}
table,th,td,tr{
    padding:auto ;
    border-collapse:2px solid greenyellow;
    color:white;
}
.cont{
    margin-left:200px;  
}
.foter{
    height:90px;
    width:auto;
    background-color:green;
}
.mennu{
    border: 1px solid green;
    list-style: none;
    background-color:#035356;
    color:aliceblue;
    text-align: calc(60% top);
    height:50px;
    width: calc(100%);
}
.mennu li{
    text-align: center;
    width: 80px;
    height: 20px;
    margin-left: 15%;
    text-decoration: white;
    display:inline-flex;
    border: 1px solid greenyellow;
    background-color: black;
}
.mennu a{
    text-align: center;
    text-decoration: none;
    color: white;
}
</style>
<body>
<div class="mennu">
        <ul>
    
            <?php
        
           ?>
            <li><a href="http://localhost/assetmanagement/include/admin/dashboard.php">Admin</a></li>
            <?php
            if(isset($_SESSION['id'])){
            ?>
            <li><a href="http://localhost/assetmanagement/include/users/login.php">Login</a></li>
            <li><a href="http://localhost/assetmanagement/include/users/signup.php">Signup</a></li>
            <li><a href="http://localhost/assetmanagement/asset/index.php">Asset</a></li>
            <?php
             }else{
                ?>
                <li><a href="http://localhost/assetmanagement/include/users/logout.php">Logout</a></li>
            </ul>
            </div>
            <?php
        }
        ?>
        </ul>
    </div>
    <div class="maiin">
        <div class="cont">
    <h2>User Registration requests </h2>
    <table style="1 ">
        <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
        </tr>
        <tr>
            <td><?php echo $_GET['fname']; ?></td>
            <td><?php echo $_GET['lname']; ?></td>
            <td><?php echo $_GET['email']; ?></td>
        </tr>
    </table>

    <h2>Send Username and Password</h2>
    <form action="sendcred.php" method="post">
        <p>Username:<p> <input type="text" name="username"><br>
        <p>Password:</p> <input type="password" name="password"><br>
        <input type="submit" value="Send">
    </form>
    </div>
    </div>
    <div class="foter">

    </div>    
</body>
</html>