<!DOCTYPE html>
<html>
<head>
    <title>asset-management</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/contact.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <style>
        .success-message {
            color: white;
            padding: 10px;
            background-color: green;
        }
    </style>
</head>
<body>
    <div class="mennu">
        <ul>
            <?php
            if(isset($_SESSION['id'])){
            ?>
            <?php
            }else{
            ?>
            <li><a href="http://localhost/assetmanagement/index.php">Home</a></li>
            <?php
            }
            ?>
            <li><a href="http://localhost/assetmanagement/asset/index.php">Asset</a></li>
            <?php
            if(isset($_SESSION['id'])){
            ?>
            <li><a href="http://localhost/assetmanagement/asset/lists.php">Assetlist</a></li>
            <li><a href="http://localhost/assetmanagement/aboout.php">About</a></li>
            <li><a href="http://localhost/assetmanagement/contact.php">Contact</a></li>
            <li><a href="http://localhost/assetmanagement/include/admin/dashboard.php">Admin</a></li>
            <li><a href="http://localhost/assetmanagement/include/users/logout.php">Logout</a></li>
            <?php
            }else{
            ?>
            <li><a href="http://localhost/assetmanagement/include/admin/dashboard.php">Admin</a></li>
            <li><a href="http://localhost/assetmanagement/include/users/login.php">Login</a></li>
            <li><a href="http://localhost/assetmanagement/include/users/signup.php">Signup</a></li>
            <?php
            }
            ?>
        </ul>
    </div>
    <div class="maiin">
        <div class="cont">
            <p style="color:white;">If you want to work with us registor and your asset please fill the following form:- </p>
            <h1 style="color:white;">User Registration</h1>
            <form action="process.php" method="post">
                <p style="color:white;">First Name:</p> <input type="text" name="fname"><br>
                <p style="color:white;">Last Name:</p> <input type="text" name="lname"><br>
                <p style="color:white;"> Email:</p> <input type="email" name="email"><br>
                <input type="submit" value="Submit">
            </form>

            <?php
            // Display username and password received from dashboard.php
            if (isset($_GET['username']) && isset($_GET['password'])) {
            ?>
            <div class="success-message">
                <h2>Username and Password</h2>
                <p>Username: <?php echo $_GET['username']; ?></p>
                <p>Password: <?php echo $_GET['password']; ?></p>
            </div>
            <?php
            }
            ?>
        </div>
        <div class="side">
            <div class="social-icons">
                Facebook:<a href="https://www.facebook.com"><img src="facebok.png" alt="Facebook"></a><br>
                Instagram:<a href="https://www.instagram.com"><img src="instagram.png" alt="Instagram"></a><br>
                Telegram:<a href="https://www.telegram.org"><img src="telegram.png" alt="Telegram"></a><br>
                Phone :<a href="tel:+1234567890"><img src="phone.png" alt="Phone"></a><br>
                MobilePhone:<a href="tel:+1234567890"><img src="mobile.png" alt="mobilephone"></a>
            </div>
        </div>
    </div>
    <div class="foter">footer here</div>
</body>
</html>

Facebook (http://facebook.com/)
Log in or sign up to view